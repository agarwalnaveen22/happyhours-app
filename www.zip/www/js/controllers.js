angular.module('starter.controllers', [])

//MAP-CONTROLLER
.controller('mapController', function($scope, position, $state, $cordovaGeolocation, $ionicLoading) {
  // mapper.then(function(position){
  console.log(position)
  var latLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);

  var mapOptions = {
    center: latLng,
    zoom: 15,
    mapTypeId: google.maps.MapTypeId.ROADMAP,
    disableDefaultUI: true
  }
  $scope.map = new google.maps.Map(document.getElementById("map"), mapOptions);
  var im = 'http://www.robotwoods.com/dev/misc/bluecircle.png';
  var userMarker = new google.maps.Marker({
      position: latLng,
      map: $scope.map,
      icon: im
    })
    // }, function(error){
    //   console.log("Could not get location");
    // });
  $scope.centerOnMe = function() {
    if (!$scope.map) {
      return;
    }

    $scope.loading = $ionicLoading.show({
      content: 'Getting current location...',
      showBackdrop: false
    });

    navigator.geolocation.getCurrentPosition(function(pos) {
      $scope.map.setCenter(new google.maps.LatLng(pos.coords.latitude, pos.coords.longitude));
      $ionicLoading.hide();
    }, function(error) {
      alert('Unable to get location: ' + error.message);
    });
  };

  $scope.clickTest = function() {
    alert('Example of infowindow with ng-click')
  };

}, function(error) {
  console.log("Could not get location");
})

//BOOKING-CONTROLLER
.controller("bookController",  function($scope,$state){
  $scope.isNumber=function(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

	$scope.gotobookconfirm= function(){
		$state.go('bookconfirm')
	}
})

//BOOKING-CONFIRMATION-CONTROLLER
.controller("bookconfirmController",function($scope,$state,$ionicPopup, $timeout) {
 $scope.showPopup = function() {

   var myPopup = $ionicPopup.show({
     title: 'Do you want to book a cab',
     scope: $scope,
     buttons: [
       { text: 'Cancel' },
       { text: '<b>OK</b>', type: 'button-assertive'}
     ]
   });
  };
})

//HOME-CONTROLLER
.controller("homeController", function(geolocation,$cordovaGeolocation,$ionicSlideBoxDelegate, $ionicPlatform,$stateParams,$scope, $http, $state, $timeout, $ionicSideMenuDelegate, $ionicLoading, $ionicPopup, $window) {
  var posOptions={
    timeout: 10000,
    enableHighAccuracy: false
  };
  $cordovaGeolocation.getCurrentPosition(posOptions).then(function (position) {
     geolocation.currentLocation(position.coords.latitude,position.coords.longitude).success(function(data){

     })
   })


   $scope.gotomaps=function(){
     $ionicLoading.show({
      content:'Loading',
      animation:'fade-in',
      showBackdrop:true,
      maxWidth:200,
      showDelay:0
    });

   $timeout(function() {
      $ionicLoading.hide();
  	  $state.go('map')
     }, 1000);

	}

	 $scope.gotobook= function() {
		$state.go('book')
	}

     $scope.gotodeal= function() {
    $state.go('deal')
  }

$scope.navSlide = function(index){
		$ionicSlideBoxDelegate.slide(index,500);
	}

	 $ionicPlatform.registerBackButtonAction(function() {
            $scope.exitConfirmPopup = function() {
                var alertPopup = $ionicPopup.confirm({
                    title: 'Exit!!!',
                    template: 'Are You sure you want to exit??',
                    scope: $scope
                });
                alertPopup.then(function(res) {
                    if (res) {
                        alertPopup.close();
                        navigator.app.exitApp();
                    } else {
                        alertPopup.close()
                    }
                });
            }
            if ($state.current.name == 'homepage') {
                $scope.exitConfirmPopup();
            }
            else{
                 $ionicHistory.goBack();
			 }
        }, 100)

	$scope.left = function() {
		$ionicSideMenuDelegate.toggleLeft();
	};

$scope.myHistory = function() {
		$state.go('history')
}

 $scope.gotocustomersupport= function() {
    $state.go('customersupport')
  }

 $scope.gototerms= function() {
    $state.go('terms')
  }
$scope.logout = function(data) {
	  $state.go('login')
  }
})

//SIGNUP-CONTROLLER
.controller("signupController", function($scope, $http, $state, $ionicLoading, $ionicPopup, $timeout) {
	$scope.gotohomepage= function() {
		$state.go('homepage')
	}
})

//HISTORY-CONTROLLER
.controller("historyController",function()
{

})

//LOGIN-CONTROLLER
.controller("loginController", function($scope, $state, $ionicLoading, $ionicPopup, $timeout,$ionicSlideBoxDelegate) {

	$scope.gotoSignup = function(){
		$state.go('signup')
	}

  $scope.gotohomepage = function() {
    $scope.$on('$ionicView.beforeEnter', function() {
   // alert("Controller entered");
    });
    $ionicLoading.show({
      content: 'Loading',
      animation: 'fade-in',
      showBackdrop: true,
      maxWidth: 200,
      showDelay: 0
    });
    $timeout(function () {
      $ionicLoading.hide();
      $state.go('homepage')
    }, 2000);
  }
})

angular.module('starter', ['ionic','starter.controllers','starter.directives', 'starter.services','ngCordova'])

.run(function($ionicPlatform,$state) {
	$ionicPlatform.ready(function() {

	navigator.splashscreen.hide();

if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
	cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
	cordova.plugins.Keyboard.disableScroll(true)
}
if (window.StatusBar) {
StatusBar.styleLightContent();
}
})
})


.config(function($stateProvider, $urlRouterProvider,$ionicConfigProvider) {
$ionicConfigProvider.form.toggle('large').checkbox('circle');
$stateProvider


.state('customersupport',{
	url:'/customersupport',
	templateUrl:'templates/customersupport.html',
		controller:'bookconfirmController'
})

.state('terms',{
	url:'/terms',
	templateUrl:'templates/terms.html'
})

.state('history',{
	url:'/history',
	templateUrl:'templates/history.html',
	controller:'historyController',
	params:{
		data:[]
	}
})
.state('bookconfirm',{
	url:'/bookconfirm',
	templateUrl:'templates/bookconfirm.html',
	controller:'bookconfirmController'

})


.state('book',{
	url:'/book',
	templateUrl:'templates/book.html',
	controller:'bookController'
})
    .state('map', {
      url: '/maps',
      templateUrl: 'templates/map.html',
      controller: 'mapController',
      resolve: {
        position: function($cordovaGeolocation) {
          var options = {
            timeout: 10000,
            enableHighAccuracy: true
          };
          return $cordovaGeolocation.getCurrentPosition(options).then(function(position) {
            return position;
          });
        }
      }
    })
.state('login',{
	url:'/login',
	templateUrl:'templates/login.html',
	controller:'loginController'
})
.state('signup',{
	url:'/signup',
	templateUrl:'templates/signup.html',
	controller:'signupController'
})

.state('deal',{
	url:'/deal',
	templateUrl:'templates/deal.html',
	controller:'homeController'
})

.state('homepage',{
	url:'/homepage',
	templateUrl:'templates/homepage.html',
	controller:'homeController'
})
$urlRouterProvider.otherwise('/login');

})
